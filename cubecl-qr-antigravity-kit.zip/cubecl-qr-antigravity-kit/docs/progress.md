# Progress log

Newest entries at the bottom. `/next-task` appends one entry per finished task using this template:

```
## YYYY-MM-DD: <task id> <title>
- Done:
- Tests:
- Decisions:
- Dependencies added:
- Follow-ups:
```

## 2026-11-15: Planning package imported
- Done: design plan, decisions, roadmap, Antigravity rules and skills added to the repository. The design comes from the QR design discussion and builds on the LU decomposition project (LAPACK vs CubeCL on wgpu and the CubeCL CPU runtime).
- Tests: none yet.
- Decisions: D-001 to D-011 Accepted; D-012 to D-018 Proposed, to confirm in the tasks they name.
- Dependencies added: none.
- Follow-ups: run `/bootstrap-workspace` (M0.1), which also chooses the project name.
