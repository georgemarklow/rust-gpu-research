# Decisions

Binding decisions for this project. Agents must not contradict an **Accepted** decision without the human's approval. **Proposed** decisions are defaults to confirm in the named task. Add new decisions at the end with the next number; never renumber.

| ID | Date | Status | Decision | Why |
| --- | --- | --- | --- | --- |
| D-001 | 2026-11-15 | Accepted | Version 1 factors one square, column-major f32 matrix (n = 128 to 4096) on wgpu/Metal and is benchmarked against LAPACK `sgeqrf`. Explicit Q, least squares, tall-skinny, batched and f64 come later on the same design. | Reuses the LU benchmark setup; one clear goal for a solo developer. |
| D-002 | 2026-11-15 | Accepted | The algorithm is blocked Householder QR with the compact WY representation (`geqr2` panels, `larft`, `larfb`), as in LAPACK `sgeqrf`. No Gram-Schmidt variants. | Keeps Q orthogonal to machine precision; almost all work becomes matrix multiplies. |
| D-003 | 2026-11-15 | Accepted | Reflectors follow LAPACK `slarfg` exactly: β = −sign(α)·‖x‖, τ = (β − α)/β, v scaled by 1/(α − β), τ = 0 when the column below the diagonal is zero. | R and τ can then be compared with `sgeqrf` entry by entry. |
| D-004 | 2026-11-15 | Accepted | The core API is device first: `DeviceMatrix` in and out, factors kept on the device. Host-slice wrappers with LAPACK-like signatures live in `host.rs`. | Chained calls (building block, least squares) avoid host transfers; benchmarks stay simple. |
| D-005 | 2026-11-15 | Accepted | Matrices are column-major with a leading dimension `ld`; no row-major or general strides. | Matches LAPACK; `ld` gives panel and trailing views without copies. |
| D-006 | 2026-11-15 | Accepted | Trailing updates use `cubecl-matmul`, called only from `gemm.rs`, which presents a column-major matrix as a tensor with shape [rows, cols] and strides [1, ld]. | Tuned kernels; its changing API stays in one file. |
| D-007 | 2026-11-15 | Accepted | The CubeCL CPU runtime is a correctness test target only. GPU kernels are never constrained by its compiler limits. | Its 0.7 compiler rejects nested loops, loops inside `if` and several loops per kernel, and defers loads (see `.agents/rules/cubecl-kernels.md`). |
| D-008 | 2026-11-15 | Accepted | Library functions return `Result<_, QrError>` (`thiserror`) for shapes, configuration, unsupported precision and rank deficiency. | Callers can recover; launch failures inside CubeCL 0.7 still panic and are documented. |
| D-009 | 2026-11-15 | Accepted | No column pivoting in version 1. QRCP, if needed, is a separate function later. | Pivoting needs updated column norms each step and is hard to block on a GPU. |
| D-010 | 2026-11-15 | Accepted | Correctness means LAPACK's xQRT01 ratios ρ_res and ρ_orth below 30 (f64 CPU computation, ε = 2⁻²³), plus agreement with `sgeqrf`: δ_R ≤ 10⁻⁴ for n ≤ 512 and ≤ 10⁻³ above, same tolerances for τ. | One threshold works at every size; matches how LAPACK tests itself. |
| D-011 | 2026-11-15 | Accepted | Kernels are generic over `F: Float`. f64 is rejected at runtime on devices without it and is developed later on CUDA or ROCm. | f64 costs nothing to design in; Metal cannot run it. |
| D-012 | 2026-11-15 | Proposed | Pin CubeCL to the 0.7 series (`cubecl = "0.7"` with the `wgpu` and `cpu` features), the version whose API and CPU-runtime limits were verified in the LU project. Confirm in M0.1. | Known behavior; newer releases change indexing to `usize` and the launch API. |
| D-013 | 2026-11-15 | Proposed | LAPACK appears only in `<prefix>-bench`, through the `lapack` and `lapack-src` crates: Accelerate on macOS, OpenBLAS on Linux CI. Library tests use the f64 Rust reference. Confirm in M0.1. | Keeps the library free of C dependencies. |
| D-014 | 2026-11-15 | Proposed | Default panel width nb = 64 and cube size 256 threads. Confirm or change with the nb sweep in M2.6. | Matches LAPACK's typical block size and the LU project's best GPU cube size. |
| D-015 | 2026-11-15 | Proposed | Whether `geqrf` keeps each panel's T matrix (nb × k extra floats) for later Q applications, or `apply_q` rebuilds it. Decide in M3.1. | Memory against recomputation. |
| D-016 | 2026-11-15 | Proposed | CI runs GPU tests on Mesa lavapipe if CubeCL's wgpu runtime works there; otherwise GPU tests are gated by the environment variable `QR_GPU_TESTS=1` and run locally. Decide in M0.1. | GitHub-hosted runners have no GPU. |
| D-017 | 2026-11-15 | Proposed | Licensed `MIT OR Apache-2.0`. | Rust ecosystem default; compatible with CubeCL. |
| D-018 | 2026-11-15 | Proposed | Project name and crate prefix are chosen in M0.1 after checking that the crates.io names are free. | Not decided in the design discussion. |
