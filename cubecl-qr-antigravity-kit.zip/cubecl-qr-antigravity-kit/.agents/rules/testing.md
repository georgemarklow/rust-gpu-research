---
trigger: model_decision
description: "Testing strategy for this workspace. Apply when writing or changing tests, adding a kernel or driver, fixing a bug, adding test matrices, or comparing against LAPACK."
---

# Testing rules

**What every change needs.**
- New kernel: a test against the f64 reference for the smallest case, a typical case and each edge case it handles (see `/add-kernel`).
- New or changed driver: `/accuracy-check` at the sizes the roadmap task names.
- Bug fix: a regression test that fails before the fix.

**Where tests live.**
- Unit tests beside the code, in `#[cfg(test)] mod tests`.
- GPU and CPU-runtime tests in `crates/<prefix>/tests/`. One test body runs on both runtimes through a small generic helper over `R: Runtime`; the wgpu instance is the default, the CPU instance is `#[ignore]`d with a reason where its compiler rejects a kernel (D-007).
- LAPACK comparisons only in `crates/<prefix>-bench/tests/` (D-013).

**Test matrices.** Use the seeded generators from M0.4; never `thread_rng`. The required set: random entries in [0, 1); sizes that are not multiples of nb (100, 1000); a zero column; identity and diagonal; ill-conditioned with singular values from 1 to 10⁻⁶; entries near 10³⁰ and 10⁻³⁰; and one tall matrix (for example 300 × 100).

**Thresholds.** Exactly those in `numerics.md` (D-010). A test asserts the ratio and prints it, so `docs/progress.md` can record typical values.

**GPU availability.** If D-016 decides GPU tests do not run in CI, gate them with `QR_GPU_TESTS=1` and say so in the test's doc comment; `/verify` runs them locally.

**Speed.** Keep `cargo test` under about a minute: n ≤ 1024 in ordinary tests. Larger sizes (2048, 4096) run in `/accuracy-check` and the milestone gates, behind `#[ignore]` with the reason "large; run in /accuracy-check".

**Performance.** Benchmarks are not tests: they run through `/benchmark`, never inside `cargo test`.
