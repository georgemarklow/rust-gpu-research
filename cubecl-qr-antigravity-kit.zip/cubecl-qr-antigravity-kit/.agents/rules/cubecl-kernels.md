---
trigger: glob
globs: "crates/*/src/kernels/**, crates/*/src/gemm.rs, crates/*/src/blocked.rs, crates/*/src/apply.rs, crates/*/src/matrix.rs"
description: "How to write CubeCL kernels and launches in this project, including the pitfalls found in the earlier LU decomposition project with CubeCL 0.7 on wgpu/Metal and the CPU runtime."
---

# CubeCL kernel rules

These come from the LU decomposition project, which ran the same CubeCL version on wgpu/Metal and on the CubeCL CPU runtime. Each rule below was learned from a real failure.

**Kernel shape.**
- Kernels are `#[cube(launch_unchecked)]` functions generic over `F: Float`. Pass sizes as `u32` scalars (`ScalarArg::new`) and sizes that fix shared-memory lengths as `#[comptime]` arguments.
- Index with the column-major formula `col * ld + row` (plus the view's offset). Neighbouring threads must handle neighbouring rows so loads are coalesced.
- Every launch states its grid in a comment: what `ABSOLUTE_POS` maps to and why the grid covers the work exactly or is guarded.

**Comptime and runtime values (CubeCL 0.7).**
- A `let mut` initialised from a Rust constant is a compile-time value; mutating it inside a kernel panics with "Can't have a mutable operation on a const variable". Start loop counters and strides from runtime values: `let mut stride = CUBE_DIM_X / 2;`, `let mut i = k + UNIT_POS;`.
- Float literals carry a suffix: `F::new(0.0_f32)`, never `F::new(0.0)` (a future Rust error).

**Synchronisation.**
- `sync_cube()` orders shared memory within one cube only. Within a kernel, never let one thread read a global value that another thread writes; read what you need into shared memory before the barrier (as the LU pivot kernel did with the pivot value).
- Every thread of a cube must reach each `sync_cube()` the same number of times: loop bounds around a barrier must be uniform across the cube.
- Separate kernel launches on the same client run in submission order; that is the only cross-cube ordering.

**Host side (CubeCL 0.7).**
- `client.read_one(handle)` takes the handle, not `handle.binding()`.
- `client.create(f32::as_bytes(&data))` uploads; `f32::from_bytes(&bytes)` downloads.
- Reading back (`read_one`) waits for all submitted work; that is the only synchronisation point the benchmark should time against.

**The CubeCL CPU runtime (test target only, D-007).** Its 0.7 MLIR compiler fails on ordinary control flow. Do not rewrite GPU kernels for it; mark the test ignored on the CPU runtime with the reason. For reference, it rejects:
- two loops in one kernel, nested loops, `while` and `loop`;
- a loop inside an `if`, and an `if` that writes an array element inside a loop;
- loops of the form `for i in k + 1..n` in some kernels (a loop over an offset from 0 works).

It also defers loads until a value is used, so `let tmp = a[x]; a[x] = a[y]; a[y] = tmp;` silently writes wrong values: an in-place swap needs two kernels through a scratch buffer. On that runtime, the threads of a cube (`CubeDim`) are the OS threads; extra cubes run one after another.

**Launch overhead.** Each launch on wgpu/Metal costs about 15 µs regardless of size (LU project measurement; re-measured in M4.1). Count launches per column and per panel in the plan for any driver change, and prefer fewer, larger kernels.

**cubecl-matmul.** Only `gemm.rs` calls it (D-006). Describe a column-major view as a tensor with shape [rows, cols] and strides [1, ld]; a transpose swaps shape and strides. If the pinned version cannot take a strided view, copy into a contiguous workspace inside `gemm.rs` and note the cost.
