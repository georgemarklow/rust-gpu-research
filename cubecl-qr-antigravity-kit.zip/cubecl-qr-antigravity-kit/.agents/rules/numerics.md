---
trigger: model_decision
description: "Numerical conventions for the QR factorization: LAPACK slarfg sign convention, safe norms, tolerances, f64 references and flop counts. Apply when writing or reviewing anything that computes reflectors, norms, T matrices, triangular solves, accuracy checks or GFLOP/s."
---

# Numerics rules

The formulas are in `docs/design-plan.md`; this file says how to apply them.

**Reflectors (D-003).** Follow `slarfg` exactly: β = −sign(α)·√(α² + σ²), τ = (β − α)/β, v₁ = 1 and v₂ = x₂/(α − β). When σ = 0, set τ = 0, leave x₂ untouched and keep β = α. sign(0) is +1, as in LAPACK. Never use the other sign choice, even if it looks simpler: R and τ would stop matching `sgeqrf`.

**Norms.** Compute ‖x₂‖ with scaling: find s = max|xᵢ| first, then s·√Σ(xᵢ/s)², with s = 0 handled as σ = 0. A plain sum of squares overflows above about 1.8 × 10¹⁹ in f32. Reductions sum in a fixed tree order so results are reproducible run to run.

**Storage.** After `geqrf`, R is on and above the diagonal, vⱼ(2:) below it (vⱼ(1) = 1 is implicit), and τ is a separate buffer of length k = min(m, n). `materialize_v` writes the implicit ones and zeros into a workspace; the factored matrix itself is never modified to add them.

**T matrices.** Build T with the `slarft` forward, column-wise recurrence from S = VᵀV. T is upper triangular; T(i, i) = τᵢ. A panel whose τ are all zero gives T = 0.

**References.** Every accuracy statement is computed in f64 on the CPU from the f32 input (D-010):
- ρ_res = ‖A − QR‖₁ / (m · ‖A‖₁ · ε) and ρ_orth = ‖I − QᵀQ‖₁ / (m · ε), with ε = 2⁻²³; both must stay below 30.
- δ_R = max over i ≤ j of |r_ij − r_ij(LAPACK)| / ‖A‖_max and δ_τ = max |τⱼ − τⱼ(LAPACK)|; tolerance 10⁻⁴ for n ≤ 512 and 10⁻³ above.

Never loosen these thresholds to make a test pass; stop and ask (AGENTS.md).

**Flop counts.** geqrf: 2mn² − 2n³/3 (4n³/3 for square). Thin orgqr: about the same as geqrf. Use these for GFLOP/s; do not mix in the LU count (2n³/3).

**Rank deficiency.** In back substitution, treat |rᵢᵢ| ≤ 10 · ε · max|rⱼⱼ| as zero and return `QrError::RankDeficient { column: i }`.
