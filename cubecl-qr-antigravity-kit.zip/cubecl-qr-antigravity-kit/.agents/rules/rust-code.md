---
trigger: glob
globs: "**/*.rs"
description: "Rust coding conventions for this workspace: errors, panics, docs, numeric types, layout, logging and lints."
---

# Rust code conventions

**Toolchain.** Stable Rust, edition 2024. `rustfmt` defaults. `cargo clippy --workspace --all-targets -- -D warnings` must pass.

**Errors.**
- The library defines one error enum, `QrError`, with `thiserror`. `anyhow` is allowed only in binaries (`<prefix>-bench`, `xtask`) and tests.
- Every condition that can be checked before a launch returns an error instead of panicking: shapes, `ld < rows`, an invalid `QrConfig`, an unsupported precision, rank deficiency in a solve.
- `unwrap()` and `expect()` appear only in tests, or with a comment proving the invariant that makes them safe.

**Safety.** `unsafe` is allowed only around CubeCL's `launch_unchecked` and `ArrayArg::from_raw_parts`, each with a `// SAFETY:` comment naming the bounds that make it safe (for example "grid covers n columns; buffer has n * (n + threads) elements"). Any other `unsafe` needs the human's approval.

**Layout.** Matrices are column-major: element (i, j) is at `offset + j * ld + i`. Name index variables `row`/`i` and `col`/`j` consistently, and never swap the formula. Host-side helpers that build test matrices use the same layout.

**Numeric types.**
- Matrix values are generic `F: Float` in kernels and `f32` in host wrappers. Accuracy references are `f64`.
- Sizes on the host are `usize`; kernel scalars follow the pinned CubeCL version (`u32` in 0.7). Convert with checked casts (`u32::try_from`) and return `QrError::InvalidShape` on overflow.
- Use `Ord::min` / `std::cmp::min` on host integers: `x.min(y)` is ambiguous when `cubecl::prelude::*` is in scope.

**Docs.** Every public item has rustdoc. Public functions say which LAPACK routine they correspond to (`geqrf`, `orgqr`, `ormqr`, `trsm`, `gels`) and what layout they expect.

**State and logging.** No global mutable state. The library logs through the `log` facade; only binaries install a logger.

**Structure.** One module per concern, as in the design plan's workspace layout. A file above roughly 600 lines is a hint to split. Kernels live under `src/kernels/`; drivers call kernels, never the reverse.

**Tests.** Unit tests sit in `#[cfg(test)] mod tests` beside the code. GPU and CPU-runtime tests go in `crates/<prefix>/tests/`; LAPACK comparisons go in `crates/<prefix>-bench/tests/`. See `testing.md`.
