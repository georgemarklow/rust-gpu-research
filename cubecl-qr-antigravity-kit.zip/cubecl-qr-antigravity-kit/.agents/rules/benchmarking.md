---
trigger: glob
globs: "crates/*-bench/**, scripts/**, results/**"
description: "How benchmarks are run, timed, recorded in CSV and plotted, so results are comparable across milestones."
---

# Benchmarking rules

**Build.** Always `--release`. Never report numbers from a debug build.

**Warm-up.** Before timing, run each configuration (implementation, n, nb, cube size) three times untimed. Every new comptime value compiles a new kernel, so each configuration needs its own warm-up.

**Timing.** Time from just before the call to just after the result is read back (`read_one` waits for the GPU). Upload of the input is excluded and recorded separately in `h2d_ms` when measured. LAPACK is timed the same way on a fresh copy of the input.

**Repetitions.** 10 timed repetitions per configuration; report the median. Same seeded input for every implementation at a given n.

**Threads.** Record the LAPACK thread count (`OPENBLAS_NUM_THREADS` or `VECLIB_MAXIMUM_THREADS`) in `cpu_threads`. Leave the library default unless the task is a thread sweep.

**CSV schema.** One row per timed repetition, appended to `results/run_<UTC timestamp>/raw_qr.csv`:

| Column | Meaning |
| --- | --- |
| run_id | `run_<timestamp>` |
| implementation | Label shown in plots, with the configuration in brackets, for example `CUBECL GPU (nb 64, 256 threads)` or `LAPACK CPU` |
| backend | `lapack-accelerate`, `lapack-openblas`, `cubecl-wgpu` or `cubecl-cpu` |
| matrix_rows, matrix_cols | m and n |
| precision | `f32` |
| panel_width | nb, empty for LAPACK |
| cube_dim | threads per cube, empty for LAPACK |
| cpu_threads | LAPACK threads, empty for CubeCL |
| repetition | 1 to 10 |
| compute_ms | the timed interval |
| gflops | (2mn² − 2n³/3) / (compute_ms × 10⁶) |
| rho_res, rho_orth | the test ratios for this run's output |
| status | `success` or the error |

**Plots.** `scripts/plot_results.py` reads the newest CSV (or `--csv`) and saves, per metric, a linear plot and a `_log` log-log plot whose axis labels and titles say the scale is logarithmic.

**Results in git.** Raw CSVs and figures live in `results/` and are not committed unless a milestone gate cites them; gates copy the figures they cite into `docs/milestones/`.
