---
name: verify
description: Runs the full local verification suite (rustfmt, clippy with warnings as errors, all tests including GPU tests, and cargo-deny license checks) and fixes what fails. Use after any code change, before marking a task done, before committing, and whenever the user asks to check, test, lint, validate or "make it green".
---

# Verify

## Run

```
QR_GPU_TESTS=1 cargo xtask verify
```

`QR_GPU_TESTS=1` makes sure the GPU tests run locally even if D-016 gates them in CI. The task runs, in order, stopping at the first failure:

1. `cargo fmt --all --check`
2. `cargo clippy --workspace --all-targets -- -D warnings`
3. `cargo test --workspace` (wgpu tests, CPU-runtime tests not ignored, LAPACK comparisons in the bench crate)
4. `cargo deny check`, if cargo-deny is installed

If the `xtask` crate does not exist yet, run the same commands by hand.

## Fix

| Failure | What to do |
| --- | --- |
| Format | Run `cargo xtask fmt`, then rerun verify. |
| Clippy | Fix the code. An `#[allow(...)]` needs a comment explaining why the lint is wrong here. |
| Tests | Read the failure, fix the cause. Never delete, ignore or loosen a test to pass; ask if a test itself looks wrong. |
| An accuracy ratio above 30 | Treat it as a bug, not noise: check indexing (column-major, offsets, ld), the `slarfg` sign, and cross-thread reads within one kernel (`.agents/rules/cubecl-kernels.md`). |
| CubeCL panics while compiling a kernel | On the CPU runtime, see the list of unsupported patterns in `.agents/rules/cubecl-kernels.md` and mark that test ignored on the CPU runtime with the reason. On wgpu, it is a real kernel bug. |
| cargo-deny | A license or source outside `.agents/rules/dependencies.md`. Replace the dependency or ask the user; never widen the allowlist on your own. |

## Report

Summarize in a few lines: which steps ran, what failed and how it was fixed, whether GPU tests ran, and whether anything was skipped (for example cargo-deny missing, or tests ignored on the CPU runtime). A task is not done while any step fails or is skipped without the user knowing.
