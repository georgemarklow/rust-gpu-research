---
name: bootstrap-workspace
description: Chooses the project name, then creates the Cargo workspace (library crate and bench crate), xtask, CI pipeline and license policy for the CubeCL QR library, following docs/design-plan.md, and commits the result to git. Use once at the very start, whenever the repository root has no Cargo.toml, or when the user asks to set up, scaffold, initialize or name the project.
---

# Bootstrap the workspace

This turns the planning files into a compiling, verified Cargo workspace, committed to git. It covers roadmap task M0.1.

## 0. Preconditions

- If a `Cargo.toml` already exists at the repository root, stop. Report what exists and ask whether the user wants a repair instead of a fresh bootstrap.
- Read `AGENTS.md`, `docs/decisions.md` and the Workspace layout section of `docs/design-plan.md`.

## 1. Check git

Run these and keep the results:

```
git rev-parse --is-inside-work-tree
git branch --show-current
git status --porcelain
git remote get-url origin
```

- **Not a git repository:** tell the user and offer to run `git init -b main`. The remote repository (for example on GitHub) is theirs to create; this skill never creates one.
- **Uncommitted changes:** if they are only the planning files from this kit, offer to commit them first as `docs: add design plan and agent setup`. Otherwise ask the user to commit or stash them.
- **No `origin` remote:** warn that the repository URL in `Cargo.toml` stays a placeholder. Continue, and add a follow-up in step 9.

Derive a public HTTPS repository URL from `origin` without the `.git` suffix, and always strip user names, passwords and tokens: the URL is published in crate metadata.

## 2. Choose the name (D-018)

`AGENTS.md` says `Project name: TBD`. Ask the user for a name. If they have none, offer three short, pronounceable suggestions that hint at QR or Householder (avoid the `cubecl-` prefix, which belongs to the CubeCL project).

Check that the library name and `<name>-bench` are free on crates.io: `https://index.crates.io/<a>/<b>/<name>` answers 404 for a free name, where `<a>` and `<b>` are the first two and the next two letters (names of 1 to 3 letters use the `1/`, `2/` or `3/<first letter>/` paths). If a name is taken, ask again.

Record the result: the name, repository and prefix lines in `AGENTS.md`; D-018 set to Accepted with the name; the copyright line in `LICENSE-MIT` (`Copyright (c) <year> the <Name> contributors`). From here on, `<prefix>` means the chosen crate name.

## 3. Check the toolchain

Run and report versions; install what is missing (ask first if installing needs admin rights):

```
rustc --version
cargo install cargo-deny --locked
```

## 4. Create the workspace

Copy and fill the templates in `resources/`, replacing `{{prefix}}` with the prefix and `{{repository}}` with the URL from step 1:

| Template | Destination |
| --- | --- |
| `resources/workspace-Cargo.toml` | `Cargo.toml` |
| `resources/rust-toolchain.toml` | `rust-toolchain.toml` |
| `resources/cargo-config.toml` | `.cargo/config.toml` |
| `resources/ci.yml` | `.github/workflows/ci.yml` (use the current branch if it is not `main`) |
| `resources/xtask/Cargo.toml`, `resources/xtask/main.rs` | `xtask/Cargo.toml`, `xtask/src/main.rs` |
| `resources/lib-Cargo.toml`, `resources/lib.rs` | `crates/<prefix>/Cargo.toml`, `crates/<prefix>/src/lib.rs` |
| `resources/bench-Cargo.toml`, `resources/bench-main.rs` | `crates/<prefix>-bench/Cargo.toml`, `crates/<prefix>-bench/src/main.rs` |
| `resources/plot_results.py` | `scripts/plot_results.py` |

Also create `.gitignore` with `/target`, `/results` and `__pycache__/`, and `LICENSE-APACHE` with the standard Apache-2.0 text.

## 5. Confirm the Proposed decisions

- **D-012 CubeCL version:** run `cargo update -p cubecl` and `cargo tree -i cubecl-core`; check that one 0.7.x version resolves and that the `wgpu` and `cpu` features build. If 0.7 no longer resolves, stop and ask.
- **D-013 LAPACK:** build `<prefix>-bench`; on macOS it links Accelerate. If it fails, report the linker error and ask before switching backend.
- **D-016 GPU tests in CI:** push nothing yet; mark it to confirm after the first CI run (step 10). Until then, GPU tests check `QR_GPU_TESTS`.
- **D-017 license:** confirm with the user.

Set each to Accepted, or record the replacement as a new decision.

## 6. License policy

Run `cargo deny init`, then edit `deny.toml` so the license allowlist matches `.agents/rules/dependencies.md`. Run `cargo deny check licenses` and resolve anything flagged by asking the user, never by widening the list silently.

## 7. Verify

Run `cargo xtask verify` and fix until it is green.

## 8. Record

- Tick M0.1 in `docs/roadmap.md`.
- Append an entry to `docs/progress.md`: the name, crates, CubeCL and LAPACK versions, repository URL and the decisions confirmed.

## 9. Commit

Only if the folder is a git repository: check that only bootstrap files changed (`Cargo.toml`, `Cargo.lock`, `rust-toolchain.toml`, `deny.toml`, `.cargo/`, `.github/`, `.gitignore`, `crates/`, `xtask/`, `scripts/`, licenses, and the edited `AGENTS.md` and `docs/` files), then `git add -A` and `git commit -m "chore: bootstrap cargo workspace"`. Show the user the commit hash.

## 10. Push, only after asking

If an `origin` exists, ask: "Push the bootstrap commit to origin/<branch>? This starts the first CI run." Push only on an explicit yes, never force-push, and never create or change remotes. After the first CI run, settle D-016: if the GPU tests ran on lavapipe, set it Accepted with that outcome; otherwise record that GPU tests run locally with `QR_GPU_TESTS=1`.

Finally, suggest M0.2 (`/next-task`).
