//! Benchmarks the library against LAPACK `sgeqrf` and writes a results CSV.
//!
//! The timing loop, warm-up and CSV schema follow `.agents/rules/benchmarking.md`;
//! they are filled in by roadmap task M2.6 (`/benchmark`).

// Links the LAPACK backend selected in Cargo.toml (Accelerate or OpenBLAS).
extern crate lapack_src;

fn main() -> anyhow::Result<()> {
    println!("benchmark harness not implemented yet (roadmap task M2.6)");
    Ok(())
}
