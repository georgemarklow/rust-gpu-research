"""Plot QR benchmark results: execution time, GFLOP/s and speedup against LAPACK.

Reads the newest results/run_*/raw_qr*.csv (or --csv PATH), using the schema in
.agents/rules/benchmarking.md, and saves every plot twice into the run's
figures/ folder: a linear version and a log-log version with a "_log" suffix.
"""

from pathlib import Path
import argparse

import matplotlib.pyplot as plt
import pandas as pd

project_dir = Path(__file__).resolve().parent.parent
results_dir = project_dir / "results"

parser = argparse.ArgumentParser(description="Plot QR benchmark results.")
parser.add_argument("--csv", type=Path, default=None, help="A specific results CSV.")
args = parser.parse_args()

if args.csv is not None:
    csv_path = args.csv.resolve()
else:
    csv_files = sorted(results_dir.rglob("raw_qr*.csv"))
    if not csv_files:
        raise FileNotFoundError(f"No raw_qr*.csv under {results_dir}; run the benchmark first.")
    csv_path = max(csv_files, key=lambda path: path.stat().st_mtime)

run_dir = csv_path.parent
figures_dir = run_dir / "figures"
figures_dir.mkdir(parents=True, exist_ok=True)
print(f"Analysing {csv_path}")

df = pd.read_csv(csv_path)
df = df[df["status"].astype(str).str.strip() == "success"].copy()
for column in ("matrix_rows", "matrix_cols", "compute_ms"):
    df[column] = pd.to_numeric(df[column], errors="coerce")
df = df.dropna(subset=["matrix_rows", "matrix_cols", "compute_ms"])
df = df[df["compute_ms"] > 0]

summary = (
    df.groupby(["implementation", "backend", "matrix_rows", "matrix_cols"], as_index=False)
    .agg(median_compute_ms=("compute_ms", "median"), trials=("compute_ms", "count"))
)
m = summary["matrix_rows"].astype(float)
n = summary["matrix_cols"].astype(float)
# Householder QR flop count: 2mn^2 - 2n^3/3 (4n^3/3 for square matrices).
summary["gflops"] = (2 * m * n**2 - 2 * n**3 / 3) / (summary["median_compute_ms"] * 1e6)
summary.to_csv(run_dir / "summary.csv", index=False)
print(summary.to_string(index=False))


def finish(fig, ax, xlabel, ylabel, title, filename, log_scale, sizes):
    if log_scale:
        ax.set_xlabel(f"{xlabel}, log₂ scale")
        ax.set_ylabel(f"{ylabel}, log₁₀ scale")
        ax.set_title(f"{title} (log–log scale)")
        ax.set_xscale("log", base=2)
        ax.set_yscale("log")
        ax.set_xticks(sizes)
        ax.xaxis.set_major_formatter(plt.ScalarFormatter())
        ax.grid(True, which="both", alpha=0.3)
        filename = f"{filename}_log"
    else:
        ax.set_xlabel(xlabel)
        ax.set_ylabel(ylabel)
        ax.set_title(title)
        ax.grid(True, alpha=0.3)
    ax.legend()
    fig.tight_layout()
    fig.savefig(figures_dir / f"{filename}.pdf", bbox_inches="tight")
    fig.savefig(figures_dir / f"{filename}.png", dpi=300, bbox_inches="tight")
    plt.close(fig)
    print(f"Generated {filename}.pdf and .png")


def plot_metric(column, ylabel, title, filename):
    sizes = sorted(summary["matrix_cols"].unique())
    for log_scale in (False, True):
        fig, ax = plt.subplots(figsize=(8, 5))
        for name, data in summary.groupby("implementation"):
            data = data.sort_values("matrix_cols")
            ax.plot(data["matrix_cols"], data[column], marker="o", linewidth=2, label=name)
        finish(fig, ax, "Matrix columns n", ylabel, title, filename, log_scale, sizes)


plot_metric("median_compute_ms", "Median execution time (ms)", "QR execution time", "execution_time")
plot_metric("gflops", "Effective GFLOP/s", "QR throughput", "gflops")

# Speedup of every implementation relative to LAPACK at the same shape.
lapack = summary[summary["backend"].astype(str).str.startswith("lapack")]
if lapack.empty:
    print("Skipping speedup: no LAPACK rows in the CSV.")
else:
    base = lapack.groupby(["matrix_rows", "matrix_cols"])["median_compute_ms"].min()
    others = summary[~summary["backend"].astype(str).str.startswith("lapack")].copy()
    others["speedup"] = [
        base.get((r, c), float("nan")) / t
        for r, c, t in zip(others["matrix_rows"], others["matrix_cols"], others["median_compute_ms"])
    ]
    others = others.dropna(subset=["speedup"])
    others.to_csv(run_dir / "speedup.csv", index=False)
    sizes = sorted(others["matrix_cols"].unique())
    for log_scale in (False, True):
        fig, ax = plt.subplots(figsize=(8, 5))
        for name, data in others.groupby("implementation"):
            data = data.sort_values("matrix_cols")
            ax.plot(data["matrix_cols"], data["speedup"], marker="o", linewidth=2, label=name)
        ax.axhline(y=1.0, color="grey", linestyle="--", label="Equal to LAPACK")
        finish(fig, ax, "Matrix columns n", "Speedup (LAPACK time / library time)",
               "Speedup relative to LAPACK", "speedup", log_scale, sizes)
