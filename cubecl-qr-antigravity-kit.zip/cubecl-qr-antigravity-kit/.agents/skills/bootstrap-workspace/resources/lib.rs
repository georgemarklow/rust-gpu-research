//! Blocked Householder QR decomposition on GPUs with CubeCL.
//!
//! Matrices are column-major `DeviceMatrix` values that stay on the device.
//! `geqrf` returns LAPACK-style compact factors: R on and above the diagonal,
//! Householder vectors below it and the scalar factors tau, matching LAPACK
//! `sgeqrf`. The `host` module wraps everything with host slices.
//!
//! This crate is pure Rust plus CubeCL and must not depend on LAPACK or any C
//! library. See `docs/design-plan.md` in the repository for the design and its maths.
