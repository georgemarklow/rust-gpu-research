//! Developer tasks for this workspace. Run with `cargo xtask <task>`.
//!
//! Uses only the standard library so it builds instantly and never needs updating
//! when dependencies change.

use std::env;
use std::path::{Path, PathBuf};
use std::process::{Command, ExitCode};

fn main() -> ExitCode {
    let task = env::args().nth(1).unwrap_or_default();
    let result = match task.as_str() {
        "verify" => verify(),
        "fmt" => run("cargo", &["fmt", "--all"]),
        "bench" => bench(),
        "" | "help" | "--help" | "-h" => {
            print_help();
            return ExitCode::SUCCESS;
        }
        other => Err(format!("unknown task `{other}`; run `cargo xtask help`")),
    };
    match result {
        Ok(()) => ExitCode::SUCCESS,
        Err(message) => {
            eprintln!("xtask: {message}");
            ExitCode::FAILURE
        }
    }
}

fn print_help() {
    println!(
        "Usage: cargo xtask <task>\n\n\
         Tasks:\n  \
         verify  format check, clippy, tests, cargo-deny\n  \
         fmt     format the whole workspace\n  \
         bench   run the release benchmark, then plot the newest results CSV"
    );
}

/// Runs every check `/verify` relies on, stopping at the first failure.
fn verify() -> Result<(), String> {
    step("format", || run("cargo", &["fmt", "--all", "--check"]))?;
    step("clippy", || {
        run(
            "cargo",
            &[
                "clippy",
                "--workspace",
                "--all-targets",
                "--",
                "-D",
                "warnings",
            ],
        )
    })?;
    step("tests", || run("cargo", &["test", "--workspace"]))?;
    if cargo_has_subcommand("deny") {
        step("cargo-deny", || run("cargo", &["deny", "check"]))?;
    } else {
        println!(
            "xtask: warning: cargo-deny is not installed, license checks skipped \
             (install with `cargo install cargo-deny --locked`)"
        );
    }
    println!("xtask: verify passed");
    Ok(())
}

/// Runs the benchmark binary in release mode, then the plotting script.
fn bench() -> Result<(), String> {
    let bench_crate = bench_crate_name()?;
    step("benchmark", || {
        run("cargo", &["run", "--release", "-p", bench_crate.as_str()])
    })?;
    step("plots", || run("python3", &["scripts/plot_results.py"]))
}

/// Finds the crate under `crates/` whose name ends in `-bench`.
fn bench_crate_name() -> Result<String, String> {
    let crates_dir = workspace_root().join("crates");
    let entries = std::fs::read_dir(&crates_dir)
        .map_err(|error| format!("cannot read {}: {error}", crates_dir.display()))?;
    for entry in entries {
        let entry = entry.map_err(|error| format!("cannot read crates directory: {error}"))?;
        let name = entry.file_name().to_string_lossy().into_owned();
        if name.ends_with("-bench") && entry.path().join("Cargo.toml").is_file() {
            return Ok(name);
        }
    }
    Err("no crate ending in `-bench` under crates/".to_string())
}

fn step(name: &str, check: impl FnOnce() -> Result<(), String>) -> Result<(), String> {
    println!("xtask: == {name} ==");
    check().map_err(|error| format!("{name} failed: {error}"))
}

fn run(program: &str, args: &[&str]) -> Result<(), String> {
    let status = Command::new(program)
        .args(args)
        .current_dir(workspace_root())
        .status()
        .map_err(|error| format!("cannot start `{program}`: {error}"))?;
    if status.success() {
        Ok(())
    } else {
        Err(format!(
            "`{program} {}` exited with {status}",
            args.join(" ")
        ))
    }
}

fn cargo_has_subcommand(name: &str) -> bool {
    Command::new("cargo")
        .args([name, "--version"])
        .output()
        .is_ok_and(|output| output.status.success())
}

fn workspace_root() -> PathBuf {
    let manifest_dir = Path::new(env!("CARGO_MANIFEST_DIR"));
    manifest_dir
        .parent()
        .map_or_else(|| manifest_dir.to_path_buf(), Path::to_path_buf)
}
