---
name: upgrade-cubecl
description: The procedure for moving the workspace to a new CubeCL release (cubecl and all cubecl-* crates together), including the API changes seen between 0.6, 0.7 and 0.9, re-verification of accuracy and a before-and-after benchmark. Use when the user asks to upgrade CubeCL, when a needed feature exists only in a newer release, or when a dependency forces a newer CubeCL.
---

# Upgrade CubeCL

CubeCL changes its API between minor releases. Upgrade on its own branch, as its own task, never as a side effect (D-012).

## 1. Prepare

- Ask the user before starting; record the target version.
- Create a branch, for example `chore/cubecl-0.x`.
- Run `/benchmark` with the default configuration on the current version, so there is a before result.

## 2. Bump

Change the `cubecl` version once in `[workspace.dependencies]`, then:

```
cargo update -p cubecl
cargo tree -i cubecl-core
```

There must be exactly one version of every `cubecl-*` crate.

## 3. Fix the build

Known changes between releases, as seen in the LU project:

| Area | 0.6 | 0.7 | 0.9 |
| --- | --- | --- | --- |
| Reading results | `client.read_one(handle.binding())` | `client.read_one(handle)` | `client.read_one(handle)` |
| CPU runtime | none | `cpu` feature (MLIR) | `cpu` feature |
| Kernel indices | `u32` | `u32` | `usize` (`ABSOLUTE_POS`, array indexing) |
| Uploading | `client.create(f32::as_bytes(..))` | same | `client.create(Bytes::from_elems(vec))` |
| CubeDim | `CubeDim::new(x, y, z)` | same | `CubeDim::new_1d(x)`, `new_2d`, `new_3d`, `new_single()` |

Fix kernels and launches one module at a time; keep each step compiling. `gemm.rs` is the only file that should need changes for `cubecl-matmul`.

## 4. Re-verify

- `/verify`.
- `/accuracy-check` at the full gate sizes of the latest finished milestone.
- Re-run the CPU-runtime tests that are marked ignored: a newer CPU compiler may accept them. Remove each ignore that now passes and note which in `docs/progress.md`.

## 5. Compare and record

- `/benchmark` with the same configuration; report before and after.
- Update D-012 (or add a decision that supersedes it), the API table in this skill, and the CubeCL notes in `.agents/rules/cubecl-kernels.md`.
- Commit as `chore(deps): upgrade cubecl to 0.x`. Do not push or merge without the user.
