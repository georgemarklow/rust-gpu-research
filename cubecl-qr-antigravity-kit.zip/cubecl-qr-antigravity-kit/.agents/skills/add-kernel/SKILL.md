---
name: add-kernel
description: The procedure for writing or changing a CubeCL kernel in this library (make_reflector, panel_dots, panel_update, materialize_v, build_t, trmm_t, trsm, or a fused kernel), from formula to launch grid to tests against the f64 reference. Use whenever a task adds or edits a #[cube] function or its launch code.
---

# Add or change a kernel

Read `.agents/rules/cubecl-kernels.md` and `.agents/rules/numerics.md` first. They list CubeCL 0.7 pitfalls that compile fine and then fail at run time.

## 1. Specify

Write down, in the plan or the kernel's doc comment:

- **Formula:** the equation from `docs/design-plan.md` it implements, with the section name.
- **Inputs and outputs:** each buffer as a column-major view (offset, rows, cols, ld) or a vector, and which ones it writes.
- **Grid:** what `ABSOLUTE_POS` (or `UNIT_POS` and `CUBE_POS`) maps to, the `CubeDim` and `CubeCount`, and whether the grid covers the work exactly or every thread checks bounds.
- **Reads and writes:** which global values each thread reads and writes. If any thread reads a value another thread writes in the same launch, redesign (shared memory before a barrier, or two kernels).
- **Launch count:** how many launches per column and per panel the driver will make with this kernel.

## 2. Write a reference first

Make sure the f64 reference module (`reference.rs`) has the same operation, so the test can compare entry by entry. Add it there first if it is missing.

## 3. Write the kernel

- Generic over `F: Float`; float literals with a suffix (`F::new(0.0_f32)`).
- Loop counters and strides start from runtime values, never from a Rust constant you then mutate.
- Reductions (norms, dot products): one cube, a strided per-thread pass, then a tree reduction in shared memory with `sync_cube()` and a uniform loop bound. Scaled norms take two passes (max, then sum of squares).
- Launch through a small `pub(crate)` function that checks shapes, returns `QrError` for bad input, and wraps `launch_unchecked` in `unsafe` with a `// SAFETY:` comment.

## 4. Test

In `crates/<prefix>/tests/`, through the shared runtime helper, for wgpu and (if it compiles) the CPU runtime:

| Case | Why |
| --- | --- |
| The smallest valid input (one column, b = 1, n = 1) | Off-by-one at the edges |
| A typical size, not a power of two (for example 37 × 23) | Grid rounding and bounds checks |
| A view with ld > rows and a non-zero offset | Column-major indexing |
| Each edge case the kernel handles (zero column, τ = 0, already-reduced column, huge or tiny values) | `slarfg` branches and the scaled norm |

Compare with the reference: elementwise relative error within about 10 · n · ε for f32. For anything that feeds a factorization, also run `/accuracy-check` once the driver uses it.

## 5. CPU runtime

If the CubeCL CPU runtime fails to compile the kernel, do not change the kernel. Mark that runtime's instance of the test `#[ignore = "CPU runtime: <pattern from cubecl-kernels.md>"]` and list it in the task's `docs/progress.md` entry.

## 6. Record

In the task's progress entry: the grid, the launch count per column or panel, and the largest error seen against the reference.
