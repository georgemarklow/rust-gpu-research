---
name: benchmark
description: Runs the release benchmark of the library against LAPACK sgeqrf across matrix sizes, panel widths and cube sizes, writes the results CSV, produces linear and log-log plots, and summarizes speed and GFLOP/s. Use when the user asks how fast it is, wants a comparison with LAPACK, a parameter sweep (nb, cube size, threads), plots, or at the M2 and M4 gates.
---

# Benchmark

Follow `.agents/rules/benchmarking.md` for timing, warm-up and the CSV schema.

## 1. Configure

The bench binary takes its configuration from command-line flags, with these defaults:

| Flag | Default |
| --- | --- |
| `--sizes` | 128,256,512,1024,2048,4096 |
| `--panel-widths` | 64 |
| `--cube-dims` | 256 |
| `--repetitions` | 10 |
| `--warmup` | 3 |
| `--seed` | 42 |

A sweep (M2.6, M4.3) sets `--panel-widths 32,64,128 --cube-dims 64,128,256`.

## 2. Run

Close other heavy applications first; the GPU and CPU are shared. Then:

```
cargo xtask bench
```

or, for a sweep, `cargo run --release -p <prefix>-bench -- <flags>` followed by `python3 scripts/plot_results.py`.

The binary prints the CSV path. Each configuration warms up, then times 10 repetitions; LAPACK runs on the same input.

## 3. Check before reporting

- Every row has `status = success` and ρ_res, ρ_orth below 30. A fast but wrong result is not a result.
- Repetition 1 is close to the median. If it is much slower, warm-up is not covering kernel compilation for that configuration.
- The LAPACK thread count is recorded in `cpu_threads`.

## 4. Report

A table of median times (ms) and GFLOP/s per implementation and size, the speedup against LAPACK, and the paths of the plots (`execution_time`, `gflops`, `speedup`, each with a `_log` version). For a sweep, name the best nb and cube size per size and whether D-014 should change.

Compare with the launch-overhead model in `docs/design-plan.md`: if the measured time at a size is close to launches × 15 µs, launches dominate, which is what M4 addresses.
