---
name: milestone-gate
description: Checks whether the current milestone's gate in docs/roadmap.md is met, demonstrates it with evidence (accuracy tables, benchmark plots), and for the M2 release runs the release checklist up to, but not including, publishing. Use when all tasks of a milestone are ticked, or when the user asks whether a milestone is done, wants a demo, a release, a changelog or a retrospective.
---

# Milestone gate

A gate is a result someone could check, not a feature count. This skill proves the gate holds and closes the milestone cleanly.

## 1. Check

- Every task of the milestone in `docs/roadmap.md` is ticked. If not, list what is open and stop.
- `/verify` passes on a clean checkout (`cargo clean` first if in doubt).
- No decision the milestone was meant to settle is still Proposed.

## 2. Demonstrate

Run the gate exactly as `docs/roadmap.md` words it, from a fresh terminal, and capture evidence in `docs/milestones/<id>-gate.md`:

| Milestone | Evidence |
| --- | --- |
| M0 | The round-trip test output and the reference-vs-`sgeqrf` table |
| M1 | `/accuracy-check` table for n = 4, 16, 128 |
| M2 | `/accuracy-check` table for n = 100 to 4096, and `/benchmark` plots against LAPACK and faer (copy the linear and log-log PNGs next to the gate file) |
| M3 | The orthogonality and least-squares tables against `sgels` |
| M4 | Benchmark plots against the M2 numbers, and the launch counts before and after |

Start the gate file with the date, the gate text quoted from the roadmap, and Passed or Failed.

## 3. Release checklist (M2 = 0.1 only)

1. Set the version to 0.1.0 in `[workspace.package]` and in the library's `[workspace.dependencies]` entry.
2. Write `CHANGELOG.md` from the `docs/progress.md` entries, grouped as Added, Changed and Fixed.
3. Check the library crate has a description, README, license files, repository and documentation link; set `publish = true` for it only.
4. Run `cargo publish --dry-run -p <prefix>` and `cargo doc --no-deps -p <prefix>` without warnings.
5. **Stop and ask the user** before the real `cargo publish`, creating a git tag, or announcing anything.

## 4. Close

- Mark the milestone done in `docs/roadmap.md` with the date, and update the Status line.
- Retrospective in `docs/progress.md`: what was planned against what happened, what was cut or moved, typical accuracy ratios, and what to change in the next milestone's plan.
- Suggest the first task of the next milestone.
