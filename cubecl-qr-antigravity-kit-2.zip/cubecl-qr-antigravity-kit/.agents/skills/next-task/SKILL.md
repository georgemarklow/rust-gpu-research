---
name: next-task
description: Runs the standard development loop for this project. It picks the next open task from docs/roadmap.md, plans it, implements it with tests, verifies it and logs progress. Use whenever the user says "continue", "next", "keep going", "work on the roadmap", "start milestone Mx", names a roadmap task id such as M1.2, or asks what to do next.
---

# Next task

One pass of this loop should finish one roadmap task completely. Finished small tasks are worth more than several half-done ones, because the developer works in short evening sessions.

## 1. Orient

- If the repository root has no `Cargo.toml`, run `/bootstrap-workspace` instead and stop.
- Run `git status --porcelain`. If there are uncommitted changes, they are probably an unfinished task from a previous session: name the task they belong to and offer to finish and commit it before picking a new one.
- Read the last three entries of `docs/progress.md`.
- Open `docs/roadmap.md` and find the current milestone: the first one with unticked tasks.
- Skim `docs/decisions.md` for decisions that touch the task, especially any still **Proposed** that this task is meant to settle.

## 2. Pick

- If the user named a task, use it. Otherwise take the first unticked task in the current milestone.
- If the task looks bigger than one session (roughly more than 500 changed lines, or more than two new kernels), split it in `docs/roadmap.md` into lettered sub-tasks first (M2.5a, M2.5b) and take the first.
- Never pick a task from a later milestone unless the user asks.

## 3. Plan

Write an implementation plan before editing code. It contains:

- the goal in one sentence and the roadmap id,
- the files and modules touched (see the design plan's workspace layout),
- public API changes (new types, functions, error variants),
- for any kernel or driver: the formula it implements (section of `docs/design-plan.md`), its launch grid, and the launches per column and per panel,
- the tests that prove it works, including the edge cases from `.agents/rules/testing.md`,
- risks, and anything in the `AGENTS.md` invariants or `.agents/rules/` that constrains it.

Wait for the user's approval if the plan changes a public API after 0.1, adds a dependency, loosens a tolerance or contradicts a decision, or if the user said "plan only". Otherwise continue.

## 4. Implement

Work in small steps that each compile. Use the specialized skills where they apply:

| Task kind | Skill |
| --- | --- |
| A new or changed CubeCL kernel | `/add-kernel` |
| A factorization driver, or anything that changes results | `/accuracy-check` |
| Timing, CSV results or plots | `/benchmark` |
| A CubeCL version change | `/upgrade-cubecl` |

## 5. Verify

Run `/verify` and fix every failure. Do not weaken, skip or delete tests to get green; if a test seems wrong, explain why and ask.

## 6. Document

- Rustdoc for every new public item, naming the LAPACK routine it corresponds to.
- `docs/design-plan.md` only if the design itself changed, together with a new entry in `docs/decisions.md`.
- When a task settles a Proposed decision, set it to Accepted (or add the replacement decision).

## 7. Record and commit

Tick the task in `docs/roadmap.md`. Append to `docs/progress.md`:

```
## YYYY-MM-DD: M1.1 make_reflector kernel
- Done: what now works, in one or two lines.
- Tests: what was added, with typical rho_res / rho_orth values where relevant.
- Decisions: none, or D-0xx with a one-line summary.
- Dependencies added: none, or name and reason.
- Follow-ups: anything discovered but not done.
```

Stage all task changes and create a local git commit with a Conventional Commits message, for example `feat(kernels): add make_reflector`. Do not push unless the user asks.

## 8. Next

If every task of the milestone is ticked, suggest `/milestone-gate`. Otherwise name the next task in one line so the user can say "continue".
