---
name: status
description: Reports where the project stands without changing anything - the current milestone and its open tasks, decisions still Proposed, the last progress entries, the git state and the suggested next step. Use when the user asks "where are we", "status", "what's left", "what did we do last time", or at the start of a session before "continue".
---

# Status

Read-only: this skill never edits files, runs builds or commits.

## 1. Gather

- `docs/roadmap.md`: the Status line, the current milestone (the first with unticked tasks), its ticked and unticked tasks, and its gate.
- `docs/decisions.md`: every decision still **Proposed**, with the task that is meant to settle it.
- `docs/progress.md`: the last three entries, including their follow-ups.
- Git: `git branch --show-current`, `git status --porcelain`, `git log --oneline -5`, and whether the branch is ahead of its upstream (`git status -sb`).

## 2. Report

Keep it to one screen:

```
Milestone: M1 Unblocked QR on the GPU (3 of 6 tasks done)
Gate: geqr2 on wgpu passes /accuracy-check and matches sgeqrf at n = 4, 16 and 128.
Done: M1.1, M1.2, M1.3
Next: M1.4 CPU-runtime pass
Open decisions: D-014 (confirm in M2.6), D-015 (decide in M3.1)
Last session: 2026-11-20, M1.3 Unblocked driver (rho_res about 2, rho_orth about 1)
Follow-ups: none
Git: main, clean, 2 commits not pushed
Suggested: say "continue" to start M1.4.
```

If the working tree has uncommitted changes, say so first: an unfinished task from a previous session may need finishing before "continue" picks a new one.
