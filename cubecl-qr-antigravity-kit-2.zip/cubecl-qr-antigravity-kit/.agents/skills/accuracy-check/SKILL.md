---
name: accuracy-check
description: Checks a QR factorization (geqr2, geqrf, orgqr or a least-squares solve) for correctness with LAPACK's test ratios and agreement with sgeqrf, across the required test matrices and sizes, and reports a table of results. Use after changing any kernel or driver that affects results, at milestone gates, and whenever the user asks whether the factorization is correct or accurate.
---

# Accuracy check

All checks are computed in f64 on the CPU from the f32 input and output (D-010). Thresholds are in `.agents/rules/numerics.md`; never change them here.

## 1. Choose the scope

- After a kernel change: the sizes in the current roadmap task.
- At a gate: the sizes in that milestone's gate. For M2 and later, n = 100, 128, 1000, 1024, 2048 and 4096, plus a 300 × 100 tall matrix.

## 2. Run

Run the accuracy tests, including the large ones that are ignored in ordinary runs:

```
QR_GPU_TESTS=1 cargo test --release -p <prefix> --test accuracy -- --include-ignored --nocapture
QR_GPU_TESTS=1 cargo test --release -p <prefix>-bench --test lapack_agreement -- --include-ignored --nocapture
```

The tests print one line per case: matrix kind, m, n, nb, ρ_res, ρ_orth, δ_R and δ_τ.

## 3. Check

| Measure | Pass |
| --- | --- |
| ρ_res = ‖A − QR‖₁ / (m · ‖A‖₁ · ε) | below 30 |
| ρ_orth = ‖I − QᵀQ‖₁ / (m · ε) | below 30 |
| δ_R against `sgeqrf` | ≤ 10⁻⁴ for n ≤ 512, ≤ 10⁻³ above |
| δ_τ against `sgeqrf` | same as δ_R |
| Least squares (from M3) | ‖x − x_LAPACK‖ / ‖x_LAPACK‖ ≤ 10⁻³ and the residual norms agree to 10⁻³ relative |

LAPACK is the only reference for δ_R and δ_τ. faer (D-019) is checked only with ρ_res and ρ_orth, because its sign convention for R may differ from `slarfg`.

Ill-conditioned matrices may show larger δ_R than random ones, because the rounding of each implementation is amplified differently; ρ_res and ρ_orth must still pass. If δ_R alone fails on the ill-conditioned case, report it with the condition number instead of loosening anything, and ask.

## 4. Diagnose failures

| Symptom | Likely cause |
| --- | --- |
| Ratios around 10⁴ or more at every size | Indexing: row and column swapped, a missing offset, ld used as rows |
| Fails only when n is not a multiple of nb | The partial last panel in the driver |
| Fails only for the zero or reduced column | The τ = 0 branch of `slarfg` |
| R matches LAPACK up to row signs | The wrong sign convention for β |
| Results change between runs | A cross-thread read of a global value inside one kernel, or a missing barrier |
| Fails only for huge or tiny entries | An unscaled norm |

## 5. Report

A table with one row per case and the four measures, the worst value of each, and pass or fail. Add the typical values to the task's `docs/progress.md` entry; at gates, include the table in `docs/milestones/<id>-gate.md`.
