---
name: record-decision
description: Records a design decision in docs/decisions.md - a new decision, accepting a Proposed one, or superseding an Accepted one - and updates the design plan, rules and roadmap that depend on it. Use when the user says "decide", "record a decision", "accept D-0xx", "change D-0xx", or when a task settles a Proposed decision or needs to depart from an Accepted one.
---

# Record a decision

Decisions bind every agent session (AGENTS.md). Changing one is the human's call; this skill writes it down consistently.

## 1. Classify

| Request | What to do |
| --- | --- |
| A new choice not covered by any decision | Add the next number (never reuse or renumber) |
| A **Proposed** decision is now settled | Set its status to Accepted, editing the text if the outcome differs |
| An **Accepted** decision must change | Only with the human's explicit approval in this conversation. Mark the old row `Superseded by D-0yy` and add the new decision as D-0yy |

## 2. Write the row

Date (today), status, the decision in one or two sentences with concrete values (versions, thresholds, names), and the reason in one sentence. If the decision came from a measurement, cite where it is recorded (a progress entry or a gate file).

## 3. Update what depends on it

Search for the decision's id and its subject across `AGENTS.md`, `docs/` and `.agents/`, and update each place that states the old choice:

- `docs/design-plan.md` when the design itself changed (its decisions table, and the section that describes the choice);
- the rule in `.agents/rules/` that enforces it;
- `docs/roadmap.md` if a task's scope or completion criteria change.

## 4. Record

Append to `docs/progress.md` (or to the current task's entry, if this happens inside `/next-task`) under Decisions: `D-0xx: <one-line summary>`. Commit as `docs(decisions): record D-0xx <short subject>` unless it is part of a task commit.
