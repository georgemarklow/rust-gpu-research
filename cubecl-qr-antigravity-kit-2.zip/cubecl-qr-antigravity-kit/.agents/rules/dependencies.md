---
trigger: glob
globs: "**/Cargo.toml, deny.toml"
description: "Dependency and license policy: allowed licenses, workspace dependencies, CubeCL pinning, and where LAPACK may appear."
---

# Dependency and license policy

**License allowlist for Rust dependencies:** MIT, Apache-2.0, Apache-2.0 WITH LLVM-exception, BSD-2-Clause, BSD-3-Clause, ISC, Zlib, Unicode-3.0, Unicode-DFS-2016, BSL-1.0, CC0-1.0, MPL-2.0. Anything else (especially GPL, LGPL or AGPL) needs the human's approval first. `cargo deny check` enforces this.

**Library crate (`<prefix>`).** Pure Rust plus CubeCL: no C dependencies and no LAPACK. Expected dependencies: `cubecl` (with `wgpu` and `cpu` features as dev or optional features), `thiserror`, `log`, and `bytemuck` if needed. Dev-dependencies may add a seeded RNG (`rand` with `StdRng`).

**Bench crate (`<prefix>-bench`).** The only place for the baselines:
- `lapack` and `lapack-src` (D-013): `accelerate` on macOS, `openblas` on Linux CI, selected by target-specific dependencies.
- `faer` (D-019), always on: pure Rust, MIT.
- `cudarc` with its `cusolver` feature (D-020), optional behind the crate's `cuda` feature. Never enable it by default, on macOS or in CI; it needs an NVIDIA GPU and the CUDA toolkit.

It also holds `chrono`, `csv`, `serde` and `anyhow` for the benchmark binary.

**CubeCL is pinned (D-012).** One version for `cubecl` and every `cubecl-*` crate, set once in `[workspace.dependencies]`. Changing it is `/upgrade-cubecl`, never a side effect of another task. `cargo tree -i cubecl-core` must show one version.

**Adding a dependency.**
1. Check it is maintained, widely used and has a license on the list.
2. Add the version once in the root `[workspace.dependencies]`; crates use `name.workspace = true`.
3. Note in `docs/progress.md` why it was added.

Prefer few dependencies. Small utilities (a 30-line function) are written in-house.

**Workspace hygiene.** Crate manifests inherit `version`, `edition`, `license`, `repository`, `rust-version` and `publish` from the workspace, and set `[lints] workspace = true`.
