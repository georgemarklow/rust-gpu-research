---
trigger: glob
globs: "crates/*-bench/**, scripts/**, results/**"
description: "How benchmarks are run against the LAPACK, faer and cuSOLVER baselines, timed, recorded in CSV and plotted, so results are comparable across milestones."
---

# Benchmarking rules

**Build.** Always `--release`. Never report numbers from a debug build.

**Warm-up.** Before timing, run each configuration (implementation, n, nb, cube size) three times untimed. Every new comptime value compiles a new kernel, so each configuration needs its own warm-up.

**Timing.** Time from just before the call to just after the result is read back (`read_one` waits for the GPU). Upload of the input is excluded and recorded separately in `h2d_ms` when measured. The baselines are timed the same way on a fresh copy of the input: LAPACK `sgeqrf`, faer's QR (D-019) and, with the `cuda` feature, cuSOLVER `geqrf` (D-020), whose timing ends with a device synchronize.

**Baselines.** LAPACK and faer run in every benchmark. faer is compared on speed and on ρ_res and ρ_orth only; R entries are not compared with faer, because its sign convention may differ. cuSOLVER runs only when the binary is built with `--features cuda` on an NVIDIA machine.

**Repetitions.** 10 timed repetitions per configuration; report the median. Same seeded input for every implementation at a given n.

**Threads.** Record the CPU baselines' thread counts in `cpu_threads`: LAPACK's (`OPENBLAS_NUM_THREADS` or `VECLIB_MAXIMUM_THREADS`) and faer's (its `Par` setting; default all cores). Leave the defaults unless the task is a thread sweep.

**CSV schema.** One row per timed repetition, appended to `results/run_<UTC timestamp>/raw_qr.csv`:

| Column | Meaning |
| --- | --- |
| run_id | `run_<timestamp>` |
| implementation | Label shown in plots, with the configuration in brackets, for example `CUBECL GPU (nb 64, 256 threads)`, `LAPACK CPU`, `FAER CPU` or `CUSOLVER GPU` |
| backend | `lapack-accelerate`, `lapack-openblas`, `faer`, `cusolver`, `cubecl-wgpu`, `cubecl-cuda` or `cubecl-cpu` |
| matrix_rows, matrix_cols | m and n |
| precision | `f32` |
| panel_width | nb, empty for the baselines |
| cube_dim | threads per cube, empty for the baselines |
| cpu_threads | LAPACK or faer threads, empty for GPU rows |
| repetition | 1 to 10 |
| compute_ms | the timed interval |
| gflops | (2mn² − 2n³/3) / (compute_ms × 10⁶) |
| rho_res, rho_orth | the test ratios for this run's output |
| status | `success` or the error |

**Plots.** `scripts/plot_results.py` reads the newest CSV (or `--csv`) and saves, per metric, a linear plot and a `_log` log-log plot whose axis labels and titles say the scale is logarithmic.

**Results in git.** Raw CSVs and figures live in `results/` and are not committed unless a milestone gate cites them; gates copy the figures they cite into `docs/milestones/`.
